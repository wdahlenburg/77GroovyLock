

var iconSet = "HTC";  //choose "HTC" or "77".
var locale = "XXXXXXX"; //Yahoo Location code.
var Clock = "12h"; // 12h or 24h.

var lang = "en"; /*
en= English
it= Italian
fr= French
de= German
sp= Spanish
da= Danish
tr= Turkish */

var tempUnit = "f"; //f=Fahrenheit c=Celsius.

var gps = "false"; 
var UseCityGPS = "false";
var UseNeighborhood = "false";
var updateInterval = "2";

/*
Models are listed as 4,5,6,6+
*/
var model = "6";




